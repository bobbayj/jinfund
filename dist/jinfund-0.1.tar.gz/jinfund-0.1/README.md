# jin-fund
Robo-advice for ETF Investing. Measuring the exposure of your ETF investments by:
1) Geography
2) Sector

Attempt #1 at creating a best-practice python project, because tutorial projects don't teach you how to structure a real application. Feedback welcome!

## Data Sources
- Blackrock ETFs; .csv files updated daily
- Vanguard ETFs; .json requests updated monthly
- Yahoo calls; yfinance library updated daily