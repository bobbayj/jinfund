from setuptools import setup, find_packages

setup(
    name='jinfund',
    version='0.1',
    packages=find_packages(),
    license='GNU GENERAL PUBLIC LICENSE V3.0',
    long_description=open('README.md').read(),
)